/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.neu.edu.controller;

import com.neu.edu.dao.MoviesDatabase;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

/**
 *
 * @author Saurabh Gujare (NUID : 001424874)
 */
public class AddMovieController extends AbstractController {
    
    public AddMovieController() {
    }
    
    protected ModelAndView handleRequestInternal(
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        
        ModelAndView mv= null;
        String title= request.getParameter("title");
        String actor= request.getParameter("actor");
        String actress= request.getParameter("actress");
        String genre= request.getParameter("genre");
        String year= request.getParameter("year");
        try {
            MoviesDatabase.setMovie(title,actor,actress,genre,year);
            System.out.println("Redirecting to AddMovieSucessPage......");
            mv = new ModelAndView("add-movie-success");
        } catch (SQLException ex) {
            System.out.println("Redirecting to AddMovieExistsPage......");
            RequestDispatcher reqAddMovieSuccessPage = request.getRequestDispatcher("WEB-INF/jsps/add-movie-exists.jsp");
            mv = new ModelAndView("add-movie-exists");
        }
        return mv;
    }
    
}
