/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.neu.edu.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

/**
 *
 * @author Saurabh Gujare (NUID : 001424874)
 */
public class RedirectController extends AbstractController {
    
    public RedirectController() {
    }
    
    protected ModelAndView handleRequestInternal(
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        ModelAndView mv= null;
        String actionValue = request.getParameter("value") == null?"":request.getParameter("value");
        
        if (actionValue.equals("")) {
            return new ModelAndView("moviestore-welcomepage");
        }
        
        switch(actionValue){              
            case "browseMovieOption":
                mv = new ModelAndView("browse-movie");
                break;
            case "addMovieOption":
                mv = new ModelAndView("add-new-movie");
                break;
        }
        return mv;
    }
    
}
